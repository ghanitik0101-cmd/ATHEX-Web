ATHEX WebView APK Project

This packages the no-login web interface into an Android WebView APK.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. APK output: app/build/outputs/apk/debug/

The project only wraps the web UI. It does not implement Android-native
injection, game modification, or access to another app's private files.
