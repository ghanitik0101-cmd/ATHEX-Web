const $=id=>document.getElementById(id);
$("launch").onclick=()=>alert("Launch requires a supported web/PWA flow.");
$("inject").onclick=()=>alert("Android-native injection cannot be performed by a browser.");
$("download").onclick=()=>alert("Connect your authorized file/config API to enable downloads.");
$("refresh").onclick=()=>alert("Connect VERSION_JSON_URL to fetch version information.");
$("save").onclick=()=>{localStorage.setItem("server",$("server").value);localStorage.setItem("version",$("version").value);alert("Settings saved.")};
$("server").value=localStorage.getItem("server")||"";
$("version").value=localStorage.getItem("version")||"";
